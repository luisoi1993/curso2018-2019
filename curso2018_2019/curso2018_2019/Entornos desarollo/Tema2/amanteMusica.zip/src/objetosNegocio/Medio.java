/*
 	* Medio.java
        *

 	* Created on 8 de septiembre de 2010, 01:14 PM
        *

 	* To change this template, choose Tools | Template Manager
 	* and open the template in the editor.
*/

package objetosNegocio;

/**
 *
 * @author Eva
 */
public class Medio {
    protected String clave;
    protected String titulo;
    protected String genero;
    protected int duracion;
    protected Fecha fecha;

    /** Creates a new instance of Medio */
    public Medio() {}

    public Medio(String clave, String titulo, String genero, int duracion,
    Fecha fecha) {
        this.clave = clave;
        this.titulo = titulo;
        this.genero = genero;
        this.duracion = duracion;
        this.fecha = fecha;
    }
    public String toString() {
        return clave + ", " + titulo + ", " + genero + ", " +
            duracion + ", " + fecha;
    }

    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo the titulo to set
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
}

