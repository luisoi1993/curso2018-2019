
/*
 	* Cancion.java
*
 	* Created on 9 de septiembre de 2010, 12:43 AM
*
 	* To change this template, choose Tools | Template Manager
 	* and open the template in the editor.
*/


package objetosNegocio;
import java.util.Vector;
import objetosNegocio.Fecha;

/**
 *
 * @author Eva
 */

public class Cancion extends Medio {
    /**
     *
     */
    protected String interprete;
    /**
     * 
     */
    protected String autorLetra;
    /**
     *
     */
    protected String autorMusica;
    /**
     *
     */
    protected String album;
    /**
     *
     */
    protected String disquera;

    /** Creates a new instance of Medio */
    public Cancion() {
        super();
    }

    /**
     * Constructor que inicializa los atributos de la clase
     * @param clave
     * @param titulo
     * @param genero
     * @param interprete
     * @param autorLetra
     * @param autorMusica
     * @param album
     * @param disquera
     * @param duracion
     * @param fecha
     */
    public Cancion(String clave, String titulo, String genero,String interprete,
            String autorLetra, String autorMusica,String album, String disquera,
            int duracion, Fecha fecha)
    {
        super(clave, titulo, genero, duracion, fecha);
        this.interprete = interprete;
        this.autorLetra = autorLetra;
        this.autorMusica = autorMusica;
        this.album = album;
        this.disquera = disquera;
    }

    /**
     *
     * @param clave
     */
    public Cancion(String clave) {
        this(clave, null, null, null, null, null, null, null, 0, null);
    }

    public String toString() {
        return super.toString() + ", " + interprete + ", " + autorLetra + ", "
        + autorMusica + ", " + album + ", " + disquera;
    }

    /**
     * @return the interprete
     */
    public String getInterprete() {
        return interprete;
    }

    /**
     * @param interprete the interprete to set
     */
    public void setInterprete(String interprete) {
        this.interprete = interprete;
    }

    /**
     * @return the autorLetra
     */
    public String getAutorLetra() {
        return autorLetra;
    }

    /**
     * @param autorLetra the autorLetra to set
     */
    public void setAutorLetra(String autorLetra) {
        this.autorLetra = autorLetra;
    }

    /**
     * @return the autorMusica
     */
    public String getAutorMusica() {
        return autorMusica;
    }

    /**
     * @param autorMusica the autorMusica to set
     */
    public void setAutorMusica(String autorMusica) {
        this.autorMusica = autorMusica;
    }

    /**
     * @return the album
     */
    public String getAlbum() {
        return album;
    }

    /**
     * @param album the album to set
     */
    public void setAlbum(String album) {
        this.album = album;
    }

    /**
     * @return the disquera
     */
    public String getDisquera() {
        return disquera;
    }

    /**
     * @param disquera the disquera to set
     */
    public void setDisquera(String disquera) {
        this.disquera = disquera;
    }
}
